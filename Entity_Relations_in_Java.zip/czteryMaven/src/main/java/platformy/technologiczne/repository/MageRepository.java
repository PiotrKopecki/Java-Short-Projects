package platformy.technologiczne.repository;

import platformy.technologiczne.Mage;
import platformy.technologiczne.Tower;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import java.util.List;

public class MageRepository {
    private final EntityManagerFactory emf;

    public MageRepository(EntityManagerFactory e){
        this.emf = e;
    }
    public Mage findMageByName(String name){
        EntityManager em = emf.createEntityManager();
        Mage  m = em.find(Mage.class,name);
        em.close();
        return m;
    }
    public void add(Mage m){
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(m);
        em.getTransaction().commit();
        em.close();
    }
    public void delete(Mage entity) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        transaction.begin();
        em.remove(em.merge(entity));
        transaction.commit();
        em.close();
    }
    public List<Mage> findAll() {
        EntityManager em = emf.createEntityManager();
        List<Mage> list = em.createQuery("select e from " + Mage.class.getSimpleName() + " e", Mage.class).getResultList();
        em.close();
        return list;
    }
}
