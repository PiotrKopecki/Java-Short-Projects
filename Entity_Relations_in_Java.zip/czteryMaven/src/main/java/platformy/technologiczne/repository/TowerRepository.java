package platformy.technologiczne.repository;

import platformy.technologiczne.Mage;
import platformy.technologiczne.Tower;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import java.util.List;

public class TowerRepository {
    private final EntityManagerFactory emf;

    public TowerRepository(EntityManagerFactory e){
        this.emf = e;
    }

    public Tower findTowerByName(String name){
        EntityManager em = emf.createEntityManager();
        Tower  t = em.find(Tower.class,name);
        em.close();
        return t;
    }
    public void add(Tower t){
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(t);
        em.getTransaction().commit();
        em.close();
    }
    public void delete(Tower entity) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        transaction.begin();
        em.remove(em.merge(entity));
        transaction.commit();
        em.close();
    }
    public List<Tower> findAll() {
        EntityManager em = emf.createEntityManager();
        List<Tower> list = em.createQuery("select e from " + Tower.class.getSimpleName() + " e", Tower.class).getResultList();
        em.close();
        return list;
    }

}
