package platformy.technologiczne;


import lombok.*;

import javax.persistence.*;

@Entity
@ToString
@EqualsAndHashCode
@Data
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class Mage {
    @Id
    private String name;
    private int level;
    @ManyToOne(fetch = FetchType.LAZY,optional = false)
    private Tower tower;
}
