package platformy.technologiczne;


import platformy.technologiczne.repository.MageRepository;
import platformy.technologiczne.repository.TowerRepository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("rpgPu");
        TowerRepository towerRepository = new TowerRepository(emf);
        MageRepository mageRepository = new MageRepository(emf);
        while(true){
            System.out.println("Podaj instrukcje: ");
            String command = scan.nextLine();
            String temp;
            if(command.contains("select")){
                if(command.contains("select * from mages where level > ")){
                    int level = Character.getNumericValue(command.charAt(command.length()-1));
                    List<Mage> list2 = mageRepository.findAll();
                    System.out.println("Znalezieni magowie: ");
                    for(int i = 0; i < list2.size(); i++){
                        if(list2.get(i).getLevel() > level){
                            System.out.println("Nazwa maga: "+list2.get(i).getName()+" Level maga: "+
                                    list2.get(i).getLevel()+" Wieza: "+list2.get(i).getTower().getName());
                        }
                    }
                }
                else if(command.contains("select * from towers where height < ")){
                    int height = Character.getNumericValue(command.charAt(command.length()-1));
                    List<Tower> list = towerRepository.findAll();
                    System.out.println("Znalezione wieze: ");
                    for(int i = 0; i < list.size(); i++){
                        if(list.get(i).getHeight() < height){
                            System.out.println("Nazwa wiezy: "+list.get(i).getName()+" Wysokosc wiezy: "+list.get(i).getHeight());
                        }
                    }
                }
                else if(command.contains("max")){
                    //pobranie wszystkich magów z poziomem wyższym niż z poziom max maga w danej wieży
                    String queryString = "SELECT MAX(m.level) FROM Tower t, Mage m WHERE m.tower = t AND t.name = :name";
                    EntityManager em = emf.createEntityManager();
                    Query query = em.createQuery(queryString);
                    query.setParameter("name", "wieza2");
                    int maxlvl = (int) query.getSingleResult();
                    queryString = "SELECT m FROM Mage m WHERE m.level > :lvl";
                    query = em.createQuery(queryString, Mage.class);
                    query.setParameter("lvl", maxlvl);
                    List<Mage> mages = query.getResultList();
                    System.out.println(mages);
                }
                continue;
            }
            switch(command) {
                case "addMage":
                    System.out.println("Podaj nazwe Maga");
                    temp = scan.nextLine();
                    Mage m = new Mage();
                    m.setName(temp);
                    System.out.println("Podaj level Maga");
                    temp = scan.nextLine();
                    m.setLevel(Integer.parseInt(temp));
                    System.out.println("Podaj nazwe wiezy badz null");
                    temp = scan.nextLine();
                    if(!temp.equals("null")){
                        Tower t = towerRepository.findTowerByName(temp);
                        if(t == null){
                            System.out.println("Blad nie ma takiej wiezy w bazie danych");
                            break;
                        }
                        m.setTower(t);
                    }
                    else{
                        System.out.println("Blad nie ma takiej wiezy w bazie danych");
                        break;
                    }
                    mageRepository.add(m);
                    break;
                case "addTower":
                    System.out.println("Podaj nazwe wiezy");
                    temp = scan.nextLine();
                    Tower  t = new Tower();
                    t.setName(temp);
                    System.out.println("Podaj wysokosc wiezy");
                    temp = scan.nextLine();
                    t.setHeight(Integer.parseInt(temp));
                    towerRepository.add(t);
                    break;
                case "show":
                    List<Tower> list = towerRepository.findAll();
                    System.out.println("Obiekty klasy Tower w bazie: ");
                    for(int i = 0; i < list.size(); i++){
                        System.out.println("Nazwa wiezy: "+list.get(i).getName()+" Wysokosc wiezy: "+list.get(i).getHeight());
                    }
                    System.out.println();
                    List<Mage> list2 = mageRepository.findAll();
                    System.out.println("Obiekty klasy Mage w bazie: ");
                    for(int j = 0; j < list2.size(); j++){
                        System.out.println("Nazwa maga: "+list2.get(j).getName()+" Level maga: "+list2.get(j).getLevel()+" Wieza: "+list2.get(j).getTower().getName());
                    }
                    break;
                case "deleteMage":
                    System.out.println("Podaj nazwe maga ktorego chcesz usunac");
                    temp = scan.nextLine();
                    m = mageRepository.findMageByName(temp);
                    if(m != null){
                        mageRepository.delete(m);
                        System.out.println("Sucess!");
                    }
                    else{
                        System.out.println("W bazie nie ma takiego maga!");
                    }
                    break;
                case "deleteTower":
                    System.out.println("Podaj nazwe wiezy ktora chcesz usunac");
                    temp = scan.nextLine();
                    t = towerRepository.findTowerByName(temp);
                    if(t != null){
                        towerRepository.delete(t);
                        System.out.println("Sucess!");
                    }
                    else{
                        System.out.println("W bazie nie ma takiej wiezy");
                    }
                    break;
                case "quit":
                    emf.close();
                    return;

            }
        }
    }

}
