# Jakarta EE Tools and Applications

## Avatar resources

This package contains avatars for users' characters.

### Purpose

Normally none of this files should be included in the project as those should be uploaded by the users. Those files are
used on the deployment time in order to populate database with some initial data.

### Credits

All character's portraits were created using [DMHeroes](http://dmheroes.com/) developed by
[Christian Oesch](https://twitter.com/ChristianOesch).
