/**
 * Entity classes for quests. Entity classes are used for storing information (e.g.: in database) and business level
 * operations.
 */
package pl.edu.pg.eti.kask.rpg.session.quest.entity;
