package pl.edu.pg.eti.kask.rpg.session.player;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.extern.java.Log;
import pl.edu.pg.eti.kask.rpg.character.entity.Character;
import pl.edu.pg.eti.kask.rpg.session.quest.QuestBoard;
import pl.edu.pg.eti.kask.rpg.session.quest.entity.Quest;

/**
 * Single virtual player. Implemented as {@link Runnable} interface describing some work to be done. Should not be
 * implemented using {@link Thread} inheritance which should be used only in cases of implementing threading low level
 * mechanism. This logic should not be implemented in {@link Character} class because of single responsibility rule.
 * The player thread will be running as long as it will be no interrupted. The {@link Runnable#run()} method implementation
 * checks the {@link Thread#interrupted()} flag as welXZl as catches {@link InterruptedException}. Reading the flag or
 * catching the exception are state consuming that means after catching exception flag will be set to false. The same
 * goes when flag is true, second read will return false.
 */
@Log
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class Player implements Runnable {

    /**
     * Character used by this player.
     */
    private Character character;

    /**
     * Board with available quests.
     */
    private QuestBoard questBoard;

    @Override
    public void run() {
        while (!Thread.interrupted()) {
            try {
                Quest quest = questBoard.take();
                System.out.println(String.format("%s will carry on epic %s quest.", character.getName(), quest.getTitle()));
                Thread.sleep(quest.getTime());
                System.out.println(String.format("%s has finished the epic quest.", character.getName()));
            } catch (InterruptedException ex) {
                break;
            }
        }
    }

}
