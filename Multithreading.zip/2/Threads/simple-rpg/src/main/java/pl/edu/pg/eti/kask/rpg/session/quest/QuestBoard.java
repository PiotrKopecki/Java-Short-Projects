package pl.edu.pg.eti.kask.rpg.session.quest;

import pl.edu.pg.eti.kask.rpg.session.quest.entity.Quest;

import java.util.ArrayList;
import java.util.List;

/**
 * Board with list of active quests. Any character can take (consume) single paper with quest so it is not available to
 * others.
 */
public class QuestBoard {

    /**
     * List of all available quests.
     */
    private List<Quest> quests = new ArrayList<>();

    /**
     * Takes quest from the board if available (removes it), otherwise waits till one will be available.
     *
     * @return single quest
     * @throws InterruptedException when thread waiting (calling {@link Object#wait()} method) for quest will be
     *                              interrupted
     */
    public synchronized Quest take() throws InterruptedException {
        while (quests.isEmpty()) {
            wait();
        }
        return quests.remove(0);
    }

    /**
     * Put new quest on the board and notify all waiting heroes.
     *
     * @param quests list of new quests
     */
    public synchronized void put(List<Quest> quests) {
        this.quests.addAll(quests);
        notifyAll();
    }

}
