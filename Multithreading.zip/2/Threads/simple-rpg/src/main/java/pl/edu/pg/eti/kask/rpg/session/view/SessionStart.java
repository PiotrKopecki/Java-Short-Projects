package pl.edu.pg.eti.kask.rpg.session.view;

import lombok.extern.java.Log;
import pl.edu.pg.eti.kask.rpg.session.service.SessionService;
import pl.edu.pg.eti.kask.rpg.view.View;

import java.util.logging.Level;

/**
 * View for presenting all data regarding characters and their professions.
 */
@Log
public class SessionStart implements View {

    /**
     * Service for session.
     */
    private final SessionService sessionService;

    /**
     * @param sessionService service for session
     */
    public SessionStart(SessionService sessionService) {
        this.sessionService = sessionService;
    }

    @Override
    public void display() {
        System.out.println("Starting new session");
        try {
            sessionService.startGenericSession(30_000).join();
            System.out.println("Session ends");
        } catch (InterruptedException ex) {
            log.log(Level.WARNING, ex.getMessage(), ex);
        }
    }

}
