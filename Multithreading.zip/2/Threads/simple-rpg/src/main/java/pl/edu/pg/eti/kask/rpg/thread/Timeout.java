package pl.edu.pg.eti.kask.rpg.thread;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Singular;
import lombok.extern.java.Log;

import java.util.List;
import java.util.logging.Level;

/**
 * The killing thread. Waits specified time after which it sends interrupt to all threads and waits for them to die.
 */
@Log
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class Timeout implements Runnable {

    /**
     * Collection of running threads.
     */
    @Singular
    private List<Thread> threads;

    /**
     * Time to wait in ms before killing threads.
     */
    private long timeout;

    @Override
    public void run() {
        try {
            Thread.sleep(timeout);
        } catch (InterruptedException ex) {
            log.log(Level.WARNING, ex.getMessage(), ex);
        }
        for (Thread thread : threads) {
            thread.interrupt();
        }
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException ex) {
                log.log(Level.WARNING, ex.getMessage(), ex);
            }
        }
    }

}
