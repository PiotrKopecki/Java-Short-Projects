/**
 * Additional comparing criteria.
 */
package pl.edu.pg.eti.kask.rpg.character.entity.comparator;
