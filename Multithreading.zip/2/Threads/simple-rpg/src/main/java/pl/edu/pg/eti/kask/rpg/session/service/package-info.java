/**
 * All business logic should be stored inside services.
 */
package pl.edu.pg.eti.kask.rpg.session.service;
