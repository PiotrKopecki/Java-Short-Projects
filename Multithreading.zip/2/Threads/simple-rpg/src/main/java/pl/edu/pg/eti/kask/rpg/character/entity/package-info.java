/**
 * Entity classes for users' game characters. Entity classes are used for storing information (e.g.: in database) and
 * business level operations.
 */
package pl.edu.pg.eti.kask.rpg.character.entity;
