/**
 * Package for all classes considering user's characters.
 */
package pl.edu.pg.eti.kask.rpg.character;
