/**
 * Entity oriented concrete repository classes.
 */
package pl.edu.pg.eti.kask.rpg.character.repository;
