/**
 * Classes responsible for creating initial data.
 */
package pl.edu.pg.eti.kask.rpg.character.initialize;
