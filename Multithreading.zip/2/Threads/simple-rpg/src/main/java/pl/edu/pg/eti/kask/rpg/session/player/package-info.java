/**
 * Virtual players implementations.
 */
package pl.edu.pg.eti.kask.rpg.session.player;
