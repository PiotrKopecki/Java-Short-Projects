/**
 * Base classes for handling data repositories. Repository is object designed to expose underlying storage (e.g.:
 * database, filesystem, memory, etc.).
 */
package pl.edu.pg.eti.kask.rpg.repository;
