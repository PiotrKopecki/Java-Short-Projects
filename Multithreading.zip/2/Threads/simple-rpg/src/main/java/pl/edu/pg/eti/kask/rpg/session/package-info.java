/**
 * Classes responsible for simple autonomous session of multiple characters started as threads.
 */
package pl.edu.pg.eti.kask.rpg.session;
