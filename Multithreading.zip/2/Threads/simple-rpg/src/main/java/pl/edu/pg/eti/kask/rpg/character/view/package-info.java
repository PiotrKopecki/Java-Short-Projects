/**
 * Views for all character oriented data.
 */
package pl.edu.pg.eti.kask.rpg.character.view;
