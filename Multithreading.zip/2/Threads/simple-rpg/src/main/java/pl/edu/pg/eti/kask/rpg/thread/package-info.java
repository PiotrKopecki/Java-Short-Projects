/**
 * General classes responsible for threads handling.
 */
package pl.edu.pg.eti.kask.rpg.thread;
