/**
 * View for session.
 */
package pl.edu.pg.eti.kask.rpg.session.view;
