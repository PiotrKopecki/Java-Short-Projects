/**
 * Classes related to quests assigned to characters.
 */
package pl.edu.pg.eti.kask.rpg.session.quest;
