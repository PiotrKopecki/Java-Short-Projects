/**
 * Main package for all source code related to the Simple RPG application. Caution, source directories in Maven based
 * projects can contain only compilable sources. All static sources (images, music, video, properties, etc.) must be
 * stored in resources directory.
 */
package pl.edu.pg.eti.kask.rpg;
