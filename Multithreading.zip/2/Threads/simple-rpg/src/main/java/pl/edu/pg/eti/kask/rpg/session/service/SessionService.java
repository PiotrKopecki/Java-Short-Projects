package pl.edu.pg.eti.kask.rpg.session.service;

import pl.edu.pg.eti.kask.rpg.character.entity.Character;
import pl.edu.pg.eti.kask.rpg.character.service.CharacterService;
import pl.edu.pg.eti.kask.rpg.session.player.GameMaster;
import pl.edu.pg.eti.kask.rpg.session.player.Player;
import pl.edu.pg.eti.kask.rpg.session.quest.QuestBoard;
import pl.edu.pg.eti.kask.rpg.session.quest.QuestGenerator;
import pl.edu.pg.eti.kask.rpg.thread.Timeout;

import java.util.ArrayList;
import java.util.List;

/**
 * Service for starting new session.
 */
public class SessionService {

    /**
     * Service for managing available characters.
     */
    private CharacterService characterService;

    /**
     * @param characterService service for managing available characters
     */
    public SessionService(CharacterService characterService) {
        this.characterService = characterService;
    }

    /**
     * Starts a new session.
     *
     * @param time time after session will end.
     * @return single thread which can be used to wait for session end
     */
    public Thread startGenericSession(long time) {
        QuestGenerator generator = new QuestGenerator();
        QuestBoard board = new QuestBoard();
        GameMaster master = GameMaster.builder()
                .questBoard(board)
                .questGenerator(generator)
                .build();

        List<Character> characters = characterService.findAllCharacters();
        List<Player> players = new ArrayList<>();
        for (Character character : characters) {
            players.add(Player.builder()
                    .character(character)
                    .questBoard(board)
                    .build());
        }

        List<Thread> threads = new ArrayList<>();
        threads.add(new Thread(master));
        for (Player player : players) {
            threads.add(new Thread(player));
        }

        Timeout timeout = Timeout.builder()
                .timeout(time)
                .threads(threads)
                .build();

        Thread timeoutThread = new Thread(timeout);
        timeoutThread.start();

        for (Thread thread : threads) {
            thread.start();
        }

        return timeoutThread;
    }

}
