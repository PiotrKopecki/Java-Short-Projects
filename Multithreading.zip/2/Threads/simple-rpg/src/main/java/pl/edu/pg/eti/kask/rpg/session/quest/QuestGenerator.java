package pl.edu.pg.eti.kask.rpg.session.quest;

import pl.edu.pg.eti.kask.rpg.session.quest.entity.Quest;

import java.util.List;
import java.util.Random;

/**
 * Component for generating new quests.
 */
public class QuestGenerator {

    /**
     * Random artifacts names generated with https://www.fantasynamegenerators.com.
     */
    private List<String> artifacts = List.of("Triumph Scroll",
            "Karma Sandals",
            "Purity Root",
            "Almighty Door",
            "Obedience Symbols",
            "Tiara of Gluttony",
            "Crown of Torment",
            "Slab of Treachery",
            "Cloak of Absorbing",
            "Chalice of Desire");

    /**
     * Random places names generated with https://www.fantasynamegenerators.com.
     */
    private List<String> places = List.of("The Narrow Caverns",
            "The Hopeless Hollows",
            "The Bleak Abyss",
            "The Desolate Cavern",
            "Grimgami Grotto",
            "Dermer Cavity",
            "Tunpawa Hole",
            "Bellgate Cavern",
            "Cardburg Hole",
            "Carnnia Overhang");

    private List<String> actions = List.of("Transport %s to %s",
            "Acquire %s from %s");

    /**
     * @return new random quest
     */
    public Quest generate() {
        Random random = new Random();
        String action = actions.get(random.nextInt(actions.size()));
        String artifact = artifacts.get(random.nextInt(artifacts.size()));
        String place = places.get(random.nextInt(places.size()));
        return Quest.builder()
                .title(String.format(action, artifact, place))
                .time(random.nextInt(5) * 1000)
                .build();
    }

}
