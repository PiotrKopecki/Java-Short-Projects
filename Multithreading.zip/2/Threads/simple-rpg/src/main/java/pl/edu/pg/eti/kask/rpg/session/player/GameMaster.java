package pl.edu.pg.eti.kask.rpg.session.player;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import pl.edu.pg.eti.kask.rpg.session.quest.QuestBoard;
import pl.edu.pg.eti.kask.rpg.session.quest.QuestGenerator;

import java.util.List;

/**
 * Virtual Game Master responsible for submitting new task for a team of heroes.
 */
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class GameMaster implements Runnable {

    /**
     * Quest generator.
     */
    private QuestGenerator questGenerator;

    /**
     * Board with available quests.
     */
    private QuestBoard questBoard;

    @Override
    public void run() {
        while (!Thread.interrupted()) {
            try {
                System.out.println("Mysterious strangers puts new quests on the board.");
                questBoard.put(List.of(questGenerator.generate(), questGenerator.generate(), questGenerator.generate()));
                Thread.sleep(10000);
            } catch (InterruptedException ex) {
                break;
            }
        }
    }

}
