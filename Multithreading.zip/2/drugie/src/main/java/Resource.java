import java.util.ArrayList;
import java.util.List;

public class Resource {
    private List<String> wyniki = new ArrayList<String>();
    private List<Integer> liczby = new ArrayList<Integer>();

    public synchronized int take() throws InterruptedException {
        while (liczby.isEmpty()) {
            wait();//Wait, maybe someone will put sth here.
        }
        int ret = liczby.remove(0);
        return ret;
    }

    public synchronized void put(int liczba) {
        this.liczby.add(liczba);
        notifyAll();
    }

    public synchronized void addWynik(String w){
        wyniki.add(w);
        System.out.println(" Dodaje wynik: " + w);
    }

    public List<String> getWyniki(){
        return this.wyniki;
    }
    public List<Integer> getLiczby(){
        return this.liczby;
    }



}
