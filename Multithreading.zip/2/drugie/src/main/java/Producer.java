import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Producer implements Runnable {
    private Resource resource;
    public Producer(Resource resource) {
        this.resource = resource;
    }

    @Override
    public void run() {
        Scanner scan = new Scanner(System.in);
        File plik_startowy = new File("C:\\Users\\piotr\\Documents\\LabyPlatformy\\Java\\2\\drugie\\src\\main\\java\\odczyt2.txt");
        Scanner scanPlik = null;
        try {
            scanPlik = new Scanner(plik_startowy);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        while(scanPlik.hasNext()){
            String numberPlik = scanPlik.nextLine();
            if(isNumeric(numberPlik)){
                System.out.println("Producer: Wrzucam do resource liczbe: " + numberPlik);
                resource.put(Integer.parseInt(numberPlik));
            }
        }
        while(true){
            String number = scan.next();
            if(isNumeric(number)){
                System.out.println("Producer: Wrzucam do resource liczbe: " + number);
                resource.put(Integer.parseInt(number));
            }
            else if(!isNumeric(number)){
                System.out.println("liczba: "+number+" nie jest liczba!, zatem koncze odczyt");
                break;
            }
        }
        scan.close();
    }

    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            int d = Integer.parseInt(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }
    public void wypiszWyniki(){
        try {
            PrintWriter zapis = new PrintWriter("C:\\Users\\piotr\\Documents\\LabyPlatformy\\Java\\2\\drugie\\src\\main\\java\\zapis.txt");
            System.out.println();
            zapis.println();
            System.out.println("Koncowe podsumowanie wynikow obliczen: ");
            zapis.println("Koncowe podsumowanie wynikow obliczen: ");
            for(int i = 0; i < resource.getWyniki().size(); i++){
                System.out.println(resource.getWyniki().get(i));
                zapis.println(resource.getWyniki().get(i));
            }
            zapis.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
}