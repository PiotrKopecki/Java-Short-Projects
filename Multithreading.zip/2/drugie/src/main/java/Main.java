import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String [] args) throws InterruptedException {

        int numberOfConsumers = Integer.parseInt(args[0]);
        Resource resource = new Resource();
        Producer producer = new Producer(resource);
        Thread threadOfProducer = new Thread(producer);
        List<Thread> listOfConsumers = new ArrayList<Thread>();
        //Consumer consumer = new Consumer(resource);
        for(int i = 0; i < numberOfConsumers; i++){     //tworze liste consumer'ow
            listOfConsumers.add(new Thread(new Consumer(resource)));
            listOfConsumers.get(i).start();
        }
        threadOfProducer.start();

        try {   //konczenie pracy
            threadOfProducer.join();
            for(int j = 0; j < listOfConsumers.size(); j++) {
                listOfConsumers.get(j).interrupt();
                listOfConsumers.get(j).join();
            }
            producer.wypiszWyniki();
        }
        catch (InterruptedException e){
            e.printStackTrace();
        }

    }

}
