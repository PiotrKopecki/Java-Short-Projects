import java.util.ArrayList;
import java.util.List;

public class Consumer implements Runnable {
    private Resource resource;
    public Consumer(Resource resource) {
        this.resource = resource;
    }
    @Override
    public void run() {
        try {
            while(!Thread.currentThread().isInterrupted()){
                checkAnotherNumber(resource.take());
            }
        } catch (InterruptedException e) {
            finishTheJob();
        }
    }
    public void finishTheJob(){     //posprawdzaj ostatnie liczby
        while(!resource.getLiczby().isEmpty()){
            try{
                checkAnotherNumber(resource.take());
            }
            catch(InterruptedException e){
                return;
            }
        }
    }
    public void checkAnotherNumber(int liczba) throws InterruptedException {
        System.out.println("Consumer: Pobieram liczbe " + liczba + " do  sprawdzenia, ID watku: "+Thread.currentThread().getId()) ;
        List<String> dzielniki = new ArrayList<String>();
        for(int i = 1; i <= liczba; i++){
            if(liczba % i == 0){
                dzielniki.add(Integer.toString(i));
            }
        }
        String n = "Liczba: " + liczba + " jej dzielniki: ";
        for(int j = 0; j < dzielniki.size(); j++){
            n += dzielniki.get(j);
            n+= " ";
        }
        resource.getWyniki().add(n);
        Thread.sleep(3000);
        System.out.println(" Dodaje wynik: " + n);
    }
}
