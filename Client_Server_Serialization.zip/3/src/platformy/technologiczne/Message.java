package platformy.technologiczne;


import lombok.Data;

import java.io.Serializable;

@Data
public class Message implements Serializable {
    static final long serialVersionUID = 13;
    private int number[] = new int[10];
    private String content;

    public Message(){

    }
}
