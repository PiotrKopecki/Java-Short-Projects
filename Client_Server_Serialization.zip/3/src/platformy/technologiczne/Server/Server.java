package platformy.technologiczne.Server;

import platformy.technologiczne.Message;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server {

    private static int port = 9797;
    public static void main(String[] args){
        int numberOfThreads;
        if (args.length > 0){
            numberOfThreads = Integer.parseInt(args[0]);
        }
        else{
            numberOfThreads = 8;
        }
        System.out.println("Serwer dziala na porcie: " + port + " moze zarzadzac " + numberOfThreads + " watkami");

        ExecutorService executorService = Executors.newFixedThreadPool(numberOfThreads);    //udostepnia pule watkow i api do przypisywania zadan
        try(ServerSocket serverSocket = new ServerSocket(port)){    //nasluchiwanie na polaczenia
            while(true){
                try{
                    final Socket socket = serverSocket.accept();
                    executorService.submit(() -> {
                        try {

                            takeCareOfMessages(socket);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });
                } catch(IOException e){
                    System.out.println("Problem with accepting client. Shutting down.");
                    System.exit(1);
                }
            }
        } catch(IOException e){
            System.out.println("Problem happend!");
            System.exit(1);
        }
    }
    public static void takeCareOfMessages(Socket socket) throws IOException {
        int numberOfMessages = 0;
        BufferedReader Input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintStream Output = new PrintStream(socket.getOutputStream());
        ObjectOutputStream oos  = new ObjectOutputStream(socket.getOutputStream());
        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
        Output.println("Serwer: gotow");
      /*  String buf = Input.readLine();
        if(isInteger(buf)){
            numberOfMessages = Integer.parseInt(buf);
            System.out.println("Serwer gotowy na przyjecie " + numberOfMessages + " obiektow klasy Message");
            Output.println("Serwer: ready for messages"); //Odpowiedź dla clienta w przypadku odebrania inta
        }*/
        try{
            int temp[];
            temp = (int[]) ois.readObject();
            numberOfMessages = temp[0];
            System.out.println("Odebrana tablica Integer: ");
            for(int i = 0; i < temp.length; i++){
                System.out.print(temp[i] + " ");
            }
            System.out.println();
            Output.println("Serwer: gotowy do odbioru");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            for(int i = 0; i < numberOfMessages; i++){
                Message mes = (Message) ois.readObject();
                System.out.println("Content wiadomosci: "+mes.getContent());
              //  System.out.println("tablica int: "+mes.getNumber());
            }
            Output.println("Serwer: skonczylem");
            socket.close();
            return;
        } catch (ClassNotFoundException e) {
            System.out.println("Nie udalo sie pobrac obiektu klasy Message!");
            socket.close();
            return;
        }
    }

    public static boolean isInteger(String s) {
        if(s == null || s.equals("")) {
            return false;
        }
        try {
            int iVal = Integer.parseInt(s);
            return true;
        }
        catch(NumberFormatException e) {
            return false;
        }
    }
}
