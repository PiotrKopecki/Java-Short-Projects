package platformy.technologiczne;


import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Random;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {
        try (Socket client = new Socket("localhost", 9797)) {
            try (InputStream is = client.getInputStream(); OutputStream os = client.getOutputStream()) {
                System.out.println("Klient polaczyl sie z serwerem na porcie: "+ client.getPort());
                String n = "0";
                int tab[] = new int[10];
                Message mes = new Message();
                Random generator = new Random();
                PrintStream out = new PrintStream(os);
                BufferedReader in = new BufferedReader(new InputStreamReader(is));
                ObjectOutputStream oos  = new ObjectOutputStream(os);
                ObjectInputStream ois = new ObjectInputStream(is);
                Scanner scan = new Scanner(System.in);

                String messageFromServer = in.readLine();
                System.out.println(messageFromServer);

                if(messageFromServer.equals("Serwer: gotow")){
                    System.out.println("Podaj n: ");
                    n = scan.nextLine();
                    tab[0] = Integer.parseInt(n);
                    for(int i = 1; i < 10; i++){
                        tab[i] = generator.nextInt(Integer.parseInt(n)) + 1;
                    }
                    mes.setNumber(tab);
                    oos.writeObject(mes.getNumber());
                    oos.flush();
                }
                messageFromServer = in.readLine();
                System.out.println(messageFromServer);
                if(messageFromServer.equals("Serwer: gotowy do odbioru")){
                    for(int i = 0; i < Integer.parseInt(n); i++){
                        System.out.println("Podaj tresc wiadomosci: ");
                        String k = scan.nextLine();
                        Message temp = mes;
                        mes = new Message();
                        mes.setNumber(temp.getNumber());
                        mes.setContent(k);
                        oos.writeObject(mes);
                        oos.flush();
                    }
                    messageFromServer = in.readLine();
                    if(messageFromServer.equals("Serwer: skonczylem")){
                        System.out.println("Klient: Koncze dzialanie bye bye");
                        client.close();
                    }
                }
            }
        } catch (UnknownHostException e) {
            System.out.println("Proba polaczenia z serwerem nie powiodla sie badz zakonczyl swoje dzialanie!");
        } catch (IOException e) {
            System.out.println("Proba polaczenia z serwerem nie powiodla sie badz zakonczyl swoje dzialanie!");
        }
        System.exit(0);

    }
}
