import org.junit.jupiter.api.Test;
import platformy.technologiczne.character.Mage;
import platformy.technologiczne.character.MageController;
import platformy.technologiczne.character.MageRepository;
import java.util.Optional;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class MageControllerTest {

    @Test
    public void Delete_NotExistObject_NotFound() {
        MageRepository mageRepository = mock(MageRepository.class);
        MageController mageController = new MageController(mageRepository);

        when(mageRepository.find("mage")).thenReturn(Optional.empty());
        doThrow(new IllegalArgumentException("IllegalArgumentException")).when(mageRepository).delete("mage");
        String result = mageController.delete("mage");

        assertThat(result).isEqualTo("not found");
        verify(mageRepository,times(1)).delete(eq("mage"));
    }


    @Test
    public void Delete_ExistObject_Done() {
        MageRepository mageRepository = mock(MageRepository.class);
        MageController mageController = new MageController(mageRepository);

        when(mageRepository.find("mage")).thenReturn(Optional.of(Mage.builder().name("mage").level(10).build()));
        String result = mageController.delete("mage");

        assertThat(result).isEqualTo("done");
        verify(mageRepository,times(1)).delete(eq("mage"));
    }

    @Test
    public void Find_NotExistObject_NotFound(){
        MageRepository mageRepository = mock(MageRepository.class);
        MageController mageController = new MageController(mageRepository);

        when(mageRepository.find("mage")).thenReturn(Optional.empty());
        String result = mageController.find("mage");

        assertThat(result).isEqualTo("not found");
        verify(mageRepository,times(1)).find(eq("mage"));
    }

    @Test
    public void Find_ExistObject_StringEntityObject(){
        Mage mage = Mage.builder()
                .name("mage")
                .level(10)
                .build();
        String resultExpect = mage.toString();

        MageRepository mageRepository = mock(MageRepository.class);
        MageController mageController = new MageController(mageRepository);

        when(mageRepository.find("mage")).thenReturn(Optional.of(mage));
        String result = mageController.find("mage");

        assertThat(result).isEqualTo(resultExpect);
        verify(mageRepository,times(1)).find(eq("mage"));
    }

    @Test
    public void Save_NewObject_Done(){
        Mage mage = Mage.builder()
                .name("mage")
                .level(10)
                .build();

        MageRepository mageRepository = mock(MageRepository.class);
        MageController mageController = new MageController(mageRepository);

        when(mageRepository.find("mage")).thenReturn(Optional.empty());
        String result = mageController.save(mage.getName(),(int)mage.getLevel());

        assertThat(result).isEqualTo("done");
        verify(mageRepository,times(1)).save(eq(mage));
    }

    @Test
    public void Save_ExistObject_BadRequest(){
        MageRepository mageRepository = mock(MageRepository.class);
        MageController mageController = new MageController(mageRepository);
        Mage mage = Mage.builder()
                .name("mage")
                .level(99)
                .build();

        doThrow(new IllegalArgumentException("IllegalArgumentException")).when(mageRepository).save(mage);
        when(mageRepository.find("mage")).thenReturn(Optional.of(mage));

        String result = mageController.save("mage",99);

        assertThat(result).isEqualTo("bad request");
        verify(mageRepository,times(1)).save(eq(mage));
    }

}
