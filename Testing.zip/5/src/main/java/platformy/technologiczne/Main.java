package platformy.technologiczne;


import platformy.technologiczne.character.Mage;
import platformy.technologiczne.character.MageController;
import platformy.technologiczne.character.MageRepository;

public class Main {
    public static void main(String[] args){
        MageController mageController = new MageController(new MageRepository());
        Mage a = Mage.builder()
                .level(10)
                .name("A")
                .build();

        Mage ab = new Mage("A",10);

        Mage ab2 = new Mage("A",10);

        System.out.println("Proba zapisania:");
        String out;
        out = mageController.save("A",10);
        System.out.println(out);
        System.out.println("Proba znalezienia:");
        out = mageController.find("A");
        System.out.println(out);
        System.out.println("Proba usuniecia:");
        out = mageController.delete("A");
        System.out.println(out);
        System.out.println("Proba usuniecia:");
        out = mageController.delete("A");
        System.out.println(out);
    }
}
