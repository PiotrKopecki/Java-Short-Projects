package platformy.technologiczne.repository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public abstract class MemoryRepository <E> {
    private Collection<E> collection;

    public MemoryRepository(){
        collection = new ArrayList<>();
    }

    public List<E> findAll(){
        return new ArrayList<>(collection);
    }

    public Optional<E> find(E entity) {
//        E object = collection.stream()
//     /           .filter(value -> entity)
        return null;
    }

    public void delete(E entity) {
        collection.remove(entity);
    }

    public void save(E entity) {
        collection.add((entity));
    }
}
