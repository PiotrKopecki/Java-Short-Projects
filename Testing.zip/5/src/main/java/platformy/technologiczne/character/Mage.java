package platformy.technologiczne.character;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Mage {
    private String name;
    private float level;
    public String toString(){
        return "Piwo: "+name+" procenty: "+level+" %";
    }
}
